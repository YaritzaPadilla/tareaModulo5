/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package formas;

/**
 *
 * @author yarit
 */
public class Formas {

    // Superclase Formas

    protected String color;

    public Formas(String color) {
        this.color = color;
    }

    public void establecerColor(String nuevoColor) {
        this.color = nuevoColor;
    }

    public void dibujar() {
        System.out.println("Dibujando una forma.");
    }
}



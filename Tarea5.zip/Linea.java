
import formas.Formas;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author yarit
 */
// Subclase Línea
class Linea extends Formas {

    public Linea(String color, double largo) {
        super(color);
    }

    @Override
    public void dibujar() {
        System.out.println("Dibujando una Línea.");
    }
}

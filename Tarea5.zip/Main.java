/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author yarit
 */
// Clase principal para probar el código
public class Main {
    public static void main(String[] args) {
        Circulo circulo = new Circulo("Rojo", 5);
        Linea linea = new Linea("Azul", 10);
        Triangulo triangulo = new Triangulo("Verde", 4, 3);
        Cuadrado cuadrado = new Cuadrado("Amarillo", 6);

        circulo.dibujar();
        System.out.println("Radio del círculo: " + circulo.calcularRadio());

        linea.dibujar();

        triangulo.dibujar();
        System.out.println("Área del triángulo: " + triangulo.calcularArea());

        cuadrado.dibujar();
        System.out.println("Área del cuadrado: " + cuadrado.calcularArea());
 }
}